\# Bulksum

A Bulk Picsum Downloader



\## How to use

1\) Download the latest from releases

2\) Unzip it

3\) Click On `linux.sh` if you have Linux or click on `windows.bat` if you have windows. Do not run the python file. It makes an error happen

4\) Enter the ammount you want to download

5\) Enter the aspect ratio (1920/1080 for 1080p)



