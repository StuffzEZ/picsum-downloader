#!/bin/bash

# Navigate to the script directory (optional, adjust if needed)
cd "$(dirname "$0")"

# Run the Python script
python3 DO-NOT-RUN-THIS-SCRIPT.py